'use strict';

/*@ngInject*/
export default function ($mdIconProvider) {
    $mdIconProvider
        .defaultIconSet('img/icons/sets/core-icons.svg', 24);
}